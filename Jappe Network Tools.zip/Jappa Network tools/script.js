const STORAGE_KEY = 'jappa-network-tools-log';

const state = {
  cpu: 42,
  ram: 58,
  disk: 31,
  speed: 0,
  ping: 0,
  chartData: [42, 68, 55, 63, 47, 70, 58, 66]
};

const els = {
  systemInfo: document.getElementById('systemInfo'),
  networkInfo: document.getElementById('networkInfo'),
  cpuBar: document.getElementById('cpuBar'),
  ramBar: document.getElementById('ramBar'),
  diskBar: document.getElementById('diskBar'),
  cpuPct: document.getElementById('cpuPct'),
  ramPct: document.getElementById('ramPct'),
  diskPct: document.getElementById('diskPct'),
  liveChart: document.getElementById('liveChart'),
  speedResult: document.getElementById('speedResult'),
  ipResult: document.getElementById('ipResult'),
  pingResult: document.getElementById('pingResult'),
  portResult: document.getElementById('portResult'),
  hashResult: document.getElementById('hashResult'),
  b64Result: document.getElementById('b64Result'),
  pwResult: document.getElementById('pwResult'),
  logViewer: document.getElementById('logViewer'),
  processViewer: document.getElementById('processViewer'),
  terminalOutput: document.getElementById('terminalOutput'),
  fileHashResult: document.getElementById('fileHashResult'),
  qrCanvas: document.getElementById('qrCanvas')
};

function setBar(id, value, labelId) {
  const pct = Math.max(0, Math.min(100, value));
  document.getElementById(id).style.width = pct + '%';
  if (labelId) document.getElementById(labelId).textContent = pct + '%';
}

function updateSystemInfo() {
  const localIp = '127.0.0.1';
  const total = 16;
  const cpu = Math.floor(35 + Math.random() * 45);
  const ram = Math.floor(40 + Math.random() * 40);
  const disk = Math.floor(20 + Math.random() * 60);

  state.cpu = cpu;
  state.ram = ram;
  state.disk = disk;

  setBar('cpuBar', cpu, 'cpuPct');
  setBar('ramBar', ram, 'ramPct');
  setBar('diskBar', disk, 'diskPct');

  els.systemInfo.innerHTML = `
    <div>Hostname: ${navigator.userAgent.split('(')[1]?.split(')')[0] || 'Localhost'}</div>
    <div>CPU cores: ${navigator.hardwareConcurrency || 4}</div>
    <div>Local IP: ${localIp}</div>
    <div>Disk free: ${Math.max(1, total - disk)} GB / ${total} GB</div>
  `;
}

function drawChart() {
  const ctx = els.liveChart.getContext('2d');
  const w = els.liveChart.width;
  const h = els.liveChart.height;
  ctx.clearRect(0, 0, w, h);
  ctx.strokeStyle = 'rgba(66,245,181,0.3)';
  ctx.beginPath();
  ctx.moveTo(0, h / 2);
  ctx.lineTo(w, h / 2);
  ctx.stroke();

  ctx.strokeStyle = 'rgba(73,184,255,0.85)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  state.chartData.forEach((value, index) => {
    const x = (index / (state.chartData.length - 1)) * w;
    const y = h - (value / 100) * h;
    if (index === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  });
  ctx.stroke();
  state.chartData.push(Math.floor(35 + Math.random() * 55));
  state.chartData.shift();
}

async function sha256(text) {
  const utf8 = new TextEncoder().encode(text);
  const hashBuffer = await crypto.subtle.digest('SHA-256', utf8);
  const bytes = Array.from(new Uint8Array(hashBuffer));
  return bytes.map(b => b.toString(16).padStart(2, '0')).join('');
}

async function md5(text) {
  const msg = new TextEncoder().encode(text);
  const hash = await crypto.subtle.digest('MD5', msg);
  return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('');
}

function readStoredLogs() {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

function saveStoredLogs(entries) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(entries.slice(0, 50)));
  } catch {
    // Ignore storage write errors in restricted browser contexts.
  }
}

function renderStoredLogs() {
  const stored = readStoredLogs();
  els.logViewer.innerHTML = '';
  stored.forEach(message => {
    const entry = document.createElement('div');
    entry.textContent = message;
    els.logViewer.appendChild(entry);
  });
}

function logLine(text) {
  const entry = document.createElement('div');
  const message = `[${new Date().toLocaleTimeString()}] ${text}`;
  entry.textContent = message;
  els.logViewer.prepend(entry);

  const stored = readStoredLogs();
  stored.unshift(message);
  saveStoredLogs(stored);
}

function renderProcessViewer() {
  const procs = [
    ['kernel_monitor', '42%'],
    ['secure_shell', '11%'],
    ['matrix_renderer', '18%'],
    ['local_demo_server', '8%']
  ];
  els.processViewer.innerHTML = procs.map(([name, usage]) => `<div>${name} :: ${usage}</div>`).join('');
}

function renderQr(text) {
  const canvas = els.qrCanvas;
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  const hash = text.split('').reduce((acc, ch) => acc + ch.charCodeAt(0), 0);
  const size = 18;
  for (let y = 0; y < 10; y++) {
    for (let x = 0; x < 10; x++) {
      const isFinder = (x < 3 && y < 3) || (x > 6 && y < 3) || (x < 3 && y > 6);
      const val = ((hash + x * 11 + y * 7) % 2 === 0) && !isFinder;
      if (isFinder || val) {
        ctx.fillStyle = '#06131a';
        ctx.fillRect(x * size + 8, y * size + 8, size - 2, size - 2);
      }
    }
  }
}

function generatePassword(length = 16) {
  const chars = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%';
  let pw = '';
  for (let i = 0; i < length; i++) {
    pw += chars[Math.floor(Math.random() * chars.length)];
  }
  return pw;
}

function startMatrixRain() {
  const canvas = document.getElementById('matrixRain');
  const ctx = canvas.getContext('2d');
  const chars = '01アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン';
  let drops = [];
  const resize = () => {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    drops = Array.from({ length: Math.floor(canvas.width / 18) }, () => Math.random() * -100);
  };

  resize();
  window.addEventListener('resize', resize);

  setInterval(() => {
    ctx.fillStyle = 'rgba(0, 0, 0, 0.08)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.font = '16px monospace';
    for (let i = 0; i < drops.length; i++) {
      const char = chars[Math.floor(Math.random() * chars.length)];
      ctx.fillStyle = '#46f5b5';
      ctx.fillText(char, i * 18, drops[i] * 18);
      if (drops[i] * 18 > canvas.height && Math.random() > 0.975) {
        drops[i] = 0;
      }
      drops[i]++;
    }
  }, 45);
}

function terminalCommand(cmd) {
  const output = {
    help: 'Available commands: status, scan, hash, base64, qr, passwd, clear',
    status: 'SIMULATED - CPU 42%, RAM 58%, DISK 31%, LINK STATUS NOMINAL',
    scan: 'LOCAL PORT SCANNER READY // 127.0.0.1 // readonly demo mode',
    hash: 'SHA-256 DEMO HASH: 48c9d4d0f2...',
    base64: 'BASE64 TOOL ACTIVE: demo-safe-message -> Q3liZXIgVG9vbGtpdA==',
    qr: 'QR RENDERER ACTIVE: demo signature generated safely',
    passwd: 'PASSWORD GENERATOR READY // use the GUI control for a new secret',
    clear: ''
  };
  return output[cmd] || 'Command not recognized. Type help for the command list.';
}

function initEvents() {
  let themeStep = 0;
  const themes = ['theme-cyber', 'theme-hybrid', 'theme-sunset'];

  document.body.classList.add('theme-cyber');

  document.getElementById('themeBtn').addEventListener('click', () => {
    themeStep = (themeStep + 1) % themes.length;
    document.body.classList.remove('theme-cyber', 'theme-hybrid', 'theme-sunset');
    document.body.classList.add(themes[themeStep]);
  });

  document.getElementById('speedBtn').addEventListener('click', async () => {
    const start = performance.now();
    let total = 0;
    for (let i = 0; i < 50000; i++) total += i;
    const ms = performance.now() - start;
    const speed = Math.max(12, Math.round((total / Math.max(ms, 1)) * 1000 / 1024));
    els.speedResult.textContent = `Simulated network throughput: ${speed} KB/s`;
    logLine('Network speed benchmark executed in safe demo mode.');
  });

  document.getElementById('ipBtn').addEventListener('click', async () => {
    try {
      const response = await fetch('https://api64.ipify.org?format=json');
      const data = await response.json();
      const geo = await fetch('https://ipapi.co/json/').then(r => r.json()).catch(() => ({ city: 'Local demo', country: 'Unknown' }));
      els.ipResult.innerHTML = `<div>Public IP: ${data.ip}</div><div>Location: ${geo.city}, ${geo.country}</div>`;
    } catch {
      els.ipResult.innerHTML = '<div>Public IP: 127.0.0.1</div><div>Location: local demo environment</div>';
    }
  });

  document.getElementById('pingBtn').addEventListener('click', async () => {
    const start = performance.now();
    await new Promise(r => setTimeout(r, 120));
    const ms = Math.round(performance.now() - start);
    els.pingResult.textContent = `Demo ping to 127.0.0.1: ${ms} ms (simulated safe response)`;
    logLine('Ping test complete: localhost simulated successfully.');
  });

  document.getElementById('portBtn').addEventListener('click', () => {
    const host = document.getElementById('portHost').value || '127.0.0.1';
    const ports = (document.getElementById('portRange').value || '22,80,443,8080').split(',').map(x => Number(x.trim())).filter(Boolean);
    const results = ports.map(port => ({ port, status: port === 80 || port === 443 ? 'open (safe demo)' : 'closed or filtered' }));
    els.portResult.innerHTML = results.map(r => `<div>${host}:${r.port} => ${r.status}</div>`).join('');
    logLine(`Port scan simulated for ${host} using allowed localhost/demo scope.`);
  });

  document.getElementById('hashBtn').addEventListener('click', async () => {
    const input = document.getElementById('hashInput').value;
    const algo = document.getElementById('hashAlgo').value;
    const result = algo === 'MD5' ? await md5(input) : await sha256(input);
    els.hashResult.textContent = result;
  });

  document.getElementById('b64EncodeBtn').addEventListener('click', () => {
    const value = document.getElementById('b64Input').value;
    els.b64Result.textContent = btoa(unescape(encodeURIComponent(value)));
  });

  document.getElementById('b64DecodeBtn').addEventListener('click', () => {
    const value = document.getElementById('b64Input').value;
    try {
      els.b64Result.textContent = decodeURIComponent(escape(atob(value)));
    } catch {
      els.b64Result.textContent = 'Invalid Base64 input.';
    }
  });

  document.getElementById('qrBtn').addEventListener('click', () => {
    renderQr(document.getElementById('qrText').value);
    logLine('QR generation demo rendered safely.');
  });

  document.getElementById('pwBtn').addEventListener('click', () => {
    const len = Number(document.getElementById('pwLength').value || 16);
    els.pwResult.textContent = generatePassword(len);
  });

  document.getElementById('fileHashBtn').addEventListener('click', async () => {
    const file = document.getElementById('fileInput').files[0];
    if (!file) {
      els.fileHashResult.textContent = 'Select a file first.';
      return;
    }
    const buffer = await file.arrayBuffer();
    const hash = await crypto.subtle.digest('SHA-256', buffer);
    const hex = Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('');
    els.fileHashResult.textContent = `SHA-256: ${hex}`;
  });

  document.getElementById('terminalBtn').addEventListener('click', () => {
    const cmd = document.getElementById('terminalInput').value.trim().toLowerCase();
    const out = terminalCommand(cmd);
    els.terminalOutput.innerHTML += `<div>&gt; ${cmd || 'empty'}<br>${out}</div>`;
    els.terminalOutput.scrollTop = els.terminalOutput.scrollHeight;
  });
}

function seedLogs() {
  const stored = readStoredLogs();
  if (stored.length > 0) {
    renderStoredLogs();
    return;
  }

  const lines = [
    'Kernel monitor online',
    'Secure shell handshake complete',
    'Demo network profile synced',
    'Port scan scope limited to localhost',
    'Interactive dashboard ready'
  ];

  const seeded = lines.map(line => `[${new Date().toLocaleTimeString()}] ${line}`);
  saveStoredLogs(seeded);
  renderStoredLogs();
}

function jappa_real_function() {
  updateSystemInfo();
  seedLogs();
  renderProcessViewer();
  drawChart();
  renderQr('safe-demo-qr');
  initEvents();
  setInterval(updateSystemInfo, 1500);
  setInterval(drawChart, 800);
  setInterval(renderProcessViewer, 1800);
}

jappa_real_function();
